package com.example.mystery;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
