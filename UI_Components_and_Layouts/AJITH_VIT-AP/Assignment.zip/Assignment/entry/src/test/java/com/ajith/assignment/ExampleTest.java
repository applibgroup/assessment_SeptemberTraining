package com.ajith.assignment;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
